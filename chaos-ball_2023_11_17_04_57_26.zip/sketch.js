let player;
let enemies = [];
let collectibles = [];
let score = 0;

let leftKey = false;
let rightKey = false;
let upKey = false;
let downKey = false;

function setup() {
  createCanvas(400, 400);
  player = createVector(width / 2, height / 2);
  setupEnemies();
  setupCollectibles();
}

function draw() {
  background(220);

  // Draw player spaceship
  fill(0, 0, 255);
  triangle(
    player.x - 15,
    player.y + 15,
    player.x + 15,
    player.y + 15,
    player.x,
    player.y - 15
  );

  // Move and draw enemies
  moveEnemies();
  drawEnemies();

  // Draw collectibles
  drawCollectibles();

  // Display score
  textSize(16);
  fill(0);
  text(`Score: ${score}`, 10, 20);

  // Check for collisions
  checkCollisions();
}

function moveEnemies() {
  for (let enemy of enemies) {
    enemy.y += enemy.speed * cos(enemy.angle);
    enemy.x += enemy.speed * sin(enemy.angle);

    if (
      enemy.y > height + 20 ||
      enemy.x < -20 ||
      enemy.x > width + 20
    ) {
      respawnEnemy(enemy);
    }
  }
}

function drawEnemies() {
  fill(255, 0, 0);
  for (let enemy of enemies) {
    ellipse(enemy.x, enemy.y, 30, 30);
  }
}

function drawCollectibles() {
  fill(0, 255, 0);
  for (let collectible of collectibles) {
    ellipse(collectible.x, collectible.y, 20, 20);
  }
}

function checkCollisions() {
  // Check for collisions with enemies
  for (let enemy of enemies) {
    let d = dist(player.x, player.y, enemy.x, enemy.y);
    if (d < 15) {
      endGame();
    }
  }

  // Check for collisions with collectibles
  for (let i = collectibles.length - 1; i >= 0; i--) {
    let d = dist(player.x, player.y, collectibles[i].x, collectibles[i].y);
    if (d < 15) {
      score += 10;
      collectibles.splice(i, 1); // Remove the collected collectible
      respawnCollectible(); // Respawn a new collectible
    }
  }
}

function keyPressed() {
  // Update variables when keys are pressed
  if (keyCode === LEFT_ARROW) {
    leftKey = true;
  } else if (keyCode === RIGHT_ARROW) {
    rightKey = true;
  } else if (keyCode === UP_ARROW) {
    upKey = true;
  } else if (keyCode === DOWN_ARROW) {
    downKey = true;
  }
}

function keyReleased() {
  // Update variables when keys are released
  if (keyCode === LEFT_ARROW) {
    leftKey = false;
  } else if (keyCode === RIGHT_ARROW) {
    rightKey = false;
  } else if (keyCode === UP_ARROW) {
    upKey = false;
  } else if (keyCode === DOWN_ARROW) {
    downKey = false;
  }
}

function updatePlayer() {
  // Move player spaceship based on key states
  if (leftKey && player.x > 15) {
    player.x -= 5;
  }
  if (rightKey && player.x < width - 15) {
    player.x += 5;
  }
  if (upKey && player.y > 15) {
    player.y -= 5;
  }
  if (downKey && player.y < height - 15) {
    player.y += 5;
  }
}

function setupEnemies() {
  // Initialize enemies with random angles
  for (let i = 0; i < 8; i++) {
    let angle = random(TWO_PI);
    let speed = random(1, 4);
    let enemy = {
      x: 0,
      y: 0,
      angle: angle,
      speed: speed,
    };
    respawnEnemy(enemy);
    enemies.push(enemy);
  }
}

function respawnEnemy(enemy) {
  // Respawn the enemy at a random angle outside the canvas
  let spawnDistance = max(width, height)/2 - 75;
  enemy.x = random(0, max(width, height)/2) + spawnDistance * cos(enemy.angle);
  enemy.y = random(0, max(width, height)/2) + spawnDistance * sin(enemy.angle);
}

function setupCollectibles() {
  // Initialize collectibles at static positions
  for (let i = 0; i < 3; i++) {
    let collectible = {
      x: random(width),
      y: random(height),
    };
    collectibles.push(collectible);
  }
}
function respawnCollectible() {
  // Respawn a collectible at a random position
  let collectible = {
    x: random(width),
    y: random(height),
  };
  collectibles.push(collectible);
}

function endGame() {
  textSize(32);
  fill(255, 0, 0);
  text("Game Over", width / 4, height / 2);
  noLoop(); // Stop the draw loop
}

// Use the setInterval function to call the update function repeatedly
setInterval(updatePlayer, 50);